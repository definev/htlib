## 0.4.0 - 2021/03/09
* null safety


## 0.3.0 - 2020/10/08
* add Windows support


## 0.2.0 - 2020/09/04
* add Linux support
* add getFullScreen and setFullScreen functions


## 0.1.0 - 2020/05/25

* add setMaxWindowSize, setMinWindowSize
* add toggleFullScreen


## 0.0.1 - 2020/05/25

* initial release
