part of 'resources.dart';

class Images {
  Images._();

  static const String htLogo = 'assets/images/HT-logo.png';
}
