import 'package:intl/intl.dart';

class DateFormats {
  static DateFormat print = DateFormat.yMEd();
}
