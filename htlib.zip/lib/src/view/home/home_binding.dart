part of 'home_screen.dart';

enum SortingState { noSort, alphabet, quantity }

enum SortingMode { lth, htl }
