part of 'renting_history_management_screen.dart';

class RentingHistoryManagement {}
