class HiveId {
  static const int book = 0;
  static const int rentingHistory = 1;
  static const int user = 2;
  static const int diagram_node = 3;
  static const int enum_diagram_mode = 4;
}
