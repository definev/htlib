package com.definev.htlib

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
